
// kdvplayertesterDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "kdvplayertester.h"
#include "kdvplayertesterDlg.h"
#include "PlayStatus.h"
#include "PicView.h"
#include "afxdialogex.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CkdvplayertesterDlg �Ի���




CkdvplayertesterDlg::CkdvplayertesterDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CkdvplayertesterDlg::IDD, pParent)
{
	m_nVideoPort  = 7200;
	m_nAudioPort  = 7202;
	m_nRomoteVidPort = 0;
	m_nRomoteAudPort = 0;
	m_nActivePT   = 106;
	m_bActivePT   = FALSE;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pRemoteIpAddress = NULL;
}

void CkdvplayertesterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_VIDEO_LOCAL_PORT, m_nVideoPort);
	DDX_Text(pDX, IDC_AUDIO_LOCAL_PORT, m_nAudioPort);
	DDX_Text(pDX, IDC_VIDEO_REMOTE_PORT, m_nRomoteVidPort);
	DDX_Text(pDX, IDC_AUDIO_REMOTE_PORT, m_nRomoteAudPort);
	DDX_Text(pDX, IDC_EDIT_ACTIVEPT, m_nActivePT);
	DDX_Control(pDX, IDC_COMBO_DECTYPE, m_comDecType);
	DDX_Control(pDX, IDC_COMBO_IFRAME, m_comboFrame);
	DDX_Control(pDX, IDC_LOCAL_IPADDR, m_cLocalIpAddr);
	DDX_Control(pDX, IDC_REMOTE_IPADDR, m_cRemoteIpAddr);
	DDX_Control(pDX, IDC_VIDEO_WINDOW_SLIDER, m_cscVideoWindow);
	DDX_Control(pDX, IDC_AUDIO_VOLUME_SLIDER, m_cscAudioVolume);
	DDX_Check(pDX, IDC_CHECK_ACTIVEPT, m_bActivePT);
	DDV_MinMaxUInt(pDX, m_nActivePT, 0, 255);
	DDX_Control(pDX, IDC_AUDIO_POWER, m_cAPStatic);

	
}

BEGIN_MESSAGE_MAP(CkdvplayertesterDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON11, &CkdvplayertesterDlg::OnBnClickedButton11)
    ON_BN_CLICKED(IDC_SET_NET_PARAM, &CkdvplayertesterDlg::OnSetNetParam)
    ON_BN_CLICKED(IDC_START_NET_RCV, &CkdvplayertesterDlg::OnStartNetRcv)
	ON_BN_CLICKED(IDC_STOP_NET_RCV, &CkdvplayertesterDlg::OnStopNetRcv)
	ON_BN_CLICKED(IDC_START_VIDEO_DECOMP, &CkdvplayertesterDlg::OnStartVideoDecomp)
	ON_BN_CLICKED(IDC_STOP_VIDEO_DECOMP, &CkdvplayertesterDlg::OnStopVideoDecomp)
	ON_BN_CLICKED(IDC_FULLSCREEN, &CkdvplayertesterDlg::OnFullscreen)
	ON_BN_CLICKED(IDC_CHECK_ACTIVEPT, &CkdvplayertesterDlg::OnCheckActivept)
	ON_CBN_SELCHANGE(IDC_COMBO_DECTYPE, &CkdvplayertesterDlg::OnSelchangeComboDectype)
	ON_BN_CLICKED(IDC_KEY_FRAME_CHECK, &CkdvplayertesterDlg::OnKeyFrameCheck)
	ON_BN_CLICKED(IDC_CLEAR, &CkdvplayertesterDlg::OnClear)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_VIDEO_WINDOW_SLIDER, &CkdvplayertesterDlg::OnReleasedcaptureVideoWindowSlider)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_AUDIO_VOLUME_SLIDER, &CkdvplayertesterDlg::OnReleasedcaptureAudioVolumeSlider)
	ON_BN_CLICKED(IDC_REDRAW, &CkdvplayertesterDlg::OnRedraw)
	ON_BN_CLICKED(IDC_STATUS, &CkdvplayertesterDlg::OnStatus)
	ON_BN_CLICKED(IDC_SNAP, &CkdvplayertesterDlg::OnSnap)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_AUDIO_VOLUME_SLIDER, &CkdvplayertesterDlg::OnReleasedcaptureAudioVolumeSlider)
	ON_BN_CLICKED(IDC_START_AUDIO_DECOMP, &CkdvplayertesterDlg::OnStartAudioDecomp)
	ON_BN_CLICKED(IDC_STOP_AUDIO_DECOMP, &CkdvplayertesterDlg::OnStopAudioDecomp)
END_MESSAGE_MAP()


void CkdvplayertesterDlg::GetLocalIp(void)
{
	s8 chCpuName[20] = {'\0'};
	s8 *pLocalIpAddress = NULL;
	hostent* pHost;
	if (gethostname(chCpuName, sizeof(chCpuName)) == 0)    //���ر��������ı�׼������,ʧ�ܷ���SOCKET_ERROR
	{
		if ((pHost = gethostbyname(chCpuName)) != NULL)    
		{
			//���ظ����������İ����������ֺ͵�ַ��Ϣ�Ľṹ��hostent��ָ��
			pLocalIpAddress = inet_ntoa(*((in_addr *)pHost->h_addr));  

		}
	}
	m_pLocalIpAddress  = pLocalIpAddress;
	//m_pRemoteIpAddress = pLocalIpAddress;
	m_cIp = (CString)pLocalIpAddress;
}


// CkdvplayertesterDlg ��Ϣ��������

BOOL CkdvplayertesterDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	if (!IsOspInitd())
	{
#ifdef _DEBUG
		OspInit(TRUE);
#else
		OspInit(FALSE);
#endif
	}	
	OspRegistModule("mediasdkvc10.dll");
	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���

	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	m_bFullScreen = FALSE;
	GetDlgItem(IDC_START_NET_RCV)->EnableWindow(FALSE);
	GetDlgItem(IDC_STOP_NET_RCV)->EnableWindow(FALSE);
	GetDlgItem(IDC_STOP_VIDEO_DECOMP)->EnableWindow(FALSE);
	GetDlgItem(IDC_DECOMP_CONFIG)->EnableWindow(FALSE);
	//GetDlgItem(IDC_START_AUDIO_DECOMP)->EnableWindow(FALSE);
	GetDlgItem(IDC_STOP_AUDIO_DECOMP)->EnableWindow(FALSE);
	GetDlgItem(IDC_FULLSCREEN)->EnableWindow(FALSE);
	//GetDlgItem(IDC_STATUS)->EnableWindow(FALSE);
	GetDlgItem(IDC_CPPUNIT)->EnableWindow(FALSE);
	GetDlgItem(IDC_GET_AUDIO_POWER)->EnableWindow(FALSE);
	GetDlgItem(IDC_COMBO_IFRAME)->EnableWindow(FALSE);
    CRect rect(20, 20, 372, 308);
	m_cPlayerWnd.Create(NULL, SS_WHITERECT | SS_NOTIFY, rect, this, IDC_PLAYER);
    m_cPlayerWnd.ShowWindow(SW_SHOW);

	GetLocalIp();
	this->SetDlgItemInt(IDC_VIDEO_LOCAL_PORT, m_nVideoPort);
	this->SetDlgItemInt(IDC_AUDIO_LOCAL_PORT,m_nAudioPort);
	this->SetDlgItemInt(IDC_VIDEO_REMOTE_PORT, m_nRomoteVidPort);
	this->SetDlgItemInt(IDC_AUDIO_REMOTE_PORT,m_nRomoteAudPort);
	this->SetDlgItemText(IDC_LOCAL_IPADDR, m_cIp);
	this->SetDlgItemText(IDC_REMOTE_IPADDR, m_cIp);

	this->m_cscAudioVolume.SetRange(0,255);
	this->m_cscAudioVolume.SetPos(128);
	this->m_cscVideoWindow.SetRange(0,352);
	this->m_cscVideoWindow.SetPos(0);

	m_comDecType.InsertString(0, _T("H261"));
	m_comDecType.InsertString(1, _T("H263"));
    m_comDecType.InsertString(2, _T("H263+"));
	m_comDecType.InsertString(3, _T("H264"));
	m_comDecType.InsertString(4, _T("MPEG2"));
	m_comDecType.InsertString(5, _T("MPEG4"));

	m_comDecType.SetItemData(0, MEDIA_TYPE_H261);
	m_comDecType.SetItemData(1, MEDIA_TYPE_H263);
	m_comDecType.SetItemData(2, MEDIA_TYPE_H263PLUS);
	m_comDecType.SetItemData(3, MEDIA_TYPE_H264);
	m_comDecType.SetItemData(4, MEDIA_TYPE_H262);
	m_comDecType.SetItemData(5, MEDIA_TYPE_MP4);

	m_comDecType.SetCurSel(3);
	m_comboFrame.SetCurSel(0);

	GetDlgItem(IDC_EDIT_ACTIVEPT)->EnableWindow(FALSE);
	m_comDecType.EnableWindow(FALSE);

    TInitAudDecoder tAudInitParam;
	memset(&tAudInitParam, 0 , sizeof(tAudInitParam));
	if (CODEC_NO_ERROR != m_KdvDecoder.InitialAudioDecoder(tAudInitParam))
	{
		AfxMessageBox(_T("Create AudioDecoder Error !"));
	}

	TInitVidDecoder tVidInitParam;
	memset(&tVidInitParam, 0 , sizeof(tVidInitParam));
	tVidInitParam.m_hwPlayVideo = m_cPlayerWnd.GetSafeHwnd();
	tVidInitParam.m_nCpuID = 0;
	if (CODEC_NO_ERROR != m_KdvDecoder.InitialVideoDecoder(tVidInitParam))
	{
		AfxMessageBox(_T("Create VideoDecoder Error !"));
	}

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CkdvplayertesterDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CkdvplayertesterDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CkdvplayertesterDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CkdvplayertesterDlg::OnBnClickedButton11()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}



void CkdvplayertesterDlg::OnSetNetParam()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	DWORD dwLocalIpAddr,dwRemoteIpAddr;
	u16 dwRet = 0;
// 	s8* pLocalIpAddress = NULL;
 	s8* pRemoteIpAddress = NULL;
// 	in_addr ipaddr;
// 
// 	m_cLocalIpAddr.GetAddress(dwLocalIpAddr);
// 	dwLocalIpAddr = htonl(dwLocalIpAddr);
// 	ipaddr.s_addr = dwLocalIpAddr;
// 	pLocalIpAddress = inet_ntoa(ipaddr);
// 
// 	m_cRemoteIpAddr.GetAddress(dwRemoteIpAddr);
// 	dwRemoteIpAddr = htonl(dwRemoteIpAddr);
// 	ipaddr.s_addr = dwRemoteIpAddr;
// 	pRemoteIpAddress = inet_ntoa(ipaddr);
	//pRemoteIpAddress = "172.16.35.100";
	m_cLocalIpAddr.GetAddress(dwLocalIpAddr);
	m_cRemoteIpAddr.GetAddress(dwRemoteIpAddr);
	//dwLocalIpAddr = htonl(dwLocalIpAddr);
	dwRemoteIpAddr = htonl(dwRemoteIpAddr);
	//in_addr ipLocaladdr = {0};
	in_addr ipRemoteaddr = {0};
	//ipLocaladdr.S_un.S_addr= dwLocalIpAddr;
	ipRemoteaddr.S_un.S_addr= dwRemoteIpAddr;
	m_pRemoteIpAddress = inet_ntoa(ipRemoteaddr);
	//m_pLocalIpAddress = inet_ntoa(ipLocaladdr);
	TMnetNetParam tLocalVidNetParam;
	memset(&tLocalVidNetParam, 0 , sizeof(tLocalVidNetParam));
	tLocalVidNetParam.m_byRemoteNum = 1;
	//s8* ipLocaladdr1 = new s8[256];
	//strcpy(ipLocaladdr1, (LPSTR)(LPCTSTR)m_cIp);


	OSP_SET_NETADDR_PORT(&tLocalVidNetParam.m_tLocalNet.tRTPAddr, AF_INET, m_nVideoPort);
	OSP_SET_NETADDR_PORT(&tLocalVidNetParam.m_tLocalNet.tRTCPAddr, AF_INET, m_nVideoPort + 1);/*m_pLocalIpAddress*/
	OSP_SET_NETADDR_ADDR_STR(&(tLocalVidNetParam.m_tLocalNet.tRTPAddr), AF_INET, (LPSTR)(LPCTSTR)m_cIp);
	OSP_SET_NETADDR_ADDR_STR(&(tLocalVidNetParam.m_tLocalNet.tRTCPAddr), AF_INET, (LPSTR)(LPCTSTR)m_cIp);
	
	OSP_SET_NETADDR_PORT(&tLocalVidNetParam.m_tRemoteNet[0].tRTPAddr, AF_INET, m_nRomoteVidPort);
	OSP_SET_NETADDR_PORT(&tLocalVidNetParam.m_tRemoteNet[0].tRTCPAddr, AF_INET, m_nRomoteVidPort + 1);/*pRemoteIpAddress*/
	OSP_SET_NETADDR_ADDR_STR(&(tLocalVidNetParam.m_tRemoteNet[0].tRTPAddr), AF_INET, m_pRemoteIpAddress);
	OSP_SET_NETADDR_ADDR_STR(&(tLocalVidNetParam.m_tRemoteNet[0].tRTCPAddr), AF_INET, m_pRemoteIpAddress);
	
	dwRet = m_KdvDecoder.SetVideoNetRcvParam(&tLocalVidNetParam);
	
	if (CODEC_NO_ERROR != dwRet)
	{
		AfxMessageBox(_T("SetVideoNetRcvParam Error !"));
		OspPrintf(TRUE, FALSE, "SetVideoNetRcvParam Error:%d\n", dwRet);
	}

	TMnetNetParam tLocalAudNetParam ;
	memset(&tLocalAudNetParam, 0, sizeof(TMnetNetParam));

	tLocalAudNetParam.m_byRemoteNum = 1;
	OSP_SET_NETADDR_PORT(&tLocalAudNetParam.m_tLocalNet.tRTPAddr, AF_INET, m_nAudioPort);
	OSP_SET_NETADDR_PORT(&tLocalAudNetParam.m_tLocalNet.tRTCPAddr, AF_INET, m_nAudioPort + 1);
	OSP_SET_NETADDR_ADDR_STR(&(tLocalAudNetParam.m_tLocalNet.tRTPAddr), AF_INET, (LPSTR)(LPCTSTR)m_cIp);
	OSP_SET_NETADDR_ADDR_STR(&(tLocalAudNetParam.m_tLocalNet.tRTCPAddr), AF_INET, (LPSTR)(LPCTSTR)m_cIp);

	if (m_pRemoteIpAddress == NULL)
	{
		s8* chIpAdress = "127.0.0.0";
		OSP_SET_NETADDR_ADDR_STR(&(tLocalAudNetParam.m_tLocalNet.tRTPAddr), AF_INET, chIpAdress);
	}
	else
	{
		OSP_SET_NETADDR_ADDR_STR(&(tLocalAudNetParam.m_tRemoteNet[0].tRTPAddr), AF_INET, m_pRemoteIpAddress);
		OSP_SET_NETADDR_ADDR_STR(&(tLocalAudNetParam.m_tRemoteNet[0].tRTCPAddr), AF_INET, m_pRemoteIpAddress);
	}
	OSP_SET_NETADDR_PORT(&tLocalAudNetParam.m_tRemoteNet[0].tRTPAddr, AF_INET, m_nRomoteAudPort);
	OSP_SET_NETADDR_PORT(&tLocalAudNetParam.m_tRemoteNet[0].tRTCPAddr, AF_INET, m_nRomoteAudPort + 1);
	dwRet = m_KdvDecoder.SetAudioNetRcvParam(&tLocalAudNetParam);

	
	if (m_bActivePT)
	{
		m_KdvDecoder.SetVideoActivePT(m_nActivePT,
			m_comDecType.GetItemData(m_comDecType.GetCurSel()));
	}
    else
	{
	//	m_KdvDecoder.SetVideoActivePT(0,106);
	}

	GetDlgItem( IDC_START_NET_RCV )->EnableWindow( TRUE );
	GetDlgItem( IDC_STOP_NET_RCV )->EnableWindow( FALSE );
	GetDlgItem( IDC_SET_NET_PARAM )->EnableWindow( FALSE );
}


void CkdvplayertesterDlg::OnStartNetRcv()
{
	// TODO: Add your control notification handler code here
	u32 dwRet = 0;
	dwRet = m_KdvDecoder.StartRcvAudio();
	if(CODEC_NO_ERROR != dwRet)
	{
		AfxMessageBox(_T("StartRcvAudio error!"));
		OspPrintf(TRUE, FALSE, "StartRcvAudio error:%d\n", dwRet);
	}

	dwRet = m_KdvDecoder.StartRcvVideo();
	if (CODEC_NO_ERROR != dwRet)
	{
		AfxMessageBox(_T("StartRcvVideo Error !"));
		OspPrintf(TRUE, FALSE, "StartRcvVideo Error : %d\n",dwRet);
	}
	GetDlgItem(IDC_START_NET_RCV)->EnableWindow(FALSE);
	GetDlgItem(IDC_STOP_NET_RCV)->EnableWindow(TRUE);
	GetDlgItem(IDC_SET_NET_PARAM)->EnableWindow(FALSE);
}


void CkdvplayertesterDlg::OnStopNetRcv()
{
	// TODO: Add your control notification handler code here
	m_KdvDecoder.StopRcvAudio();
	m_KdvDecoder.StopRcvVideo();
	GetDlgItem(IDC_START_NET_RCV)->EnableWindow(TRUE);
	GetDlgItem(IDC_STOP_NET_RCV)->EnableWindow(FALSE);
	GetDlgItem(IDC_SET_NET_PARAM)->EnableWindow(TRUE);
}


void CkdvplayertesterDlg::OnStartVideoDecomp()
{
	// TODO: Add your control notification handler code here
	if (CODEC_NO_ERROR != m_KdvDecoder.StartVideoDec())
	{
		AfxMessageBox(_T("StartVideoDec Error !"));
	}

	GetDlgItem(IDC_START_VIDEO_DECOMP)->EnableWindow(FALSE);
	GetDlgItem(IDC_STOP_VIDEO_DECOMP)->EnableWindow(TRUE);
	GetDlgItem(IDC_DECOMP_CONFIG)->EnableWindow(FALSE);
}


void CkdvplayertesterDlg::OnStopVideoDecomp()
{
	// TODO: Add your control notification handler code here
	m_KdvDecoder.StopVideoDec();
	
	m_KdvDecoder.ClearWindow();  //֮�����
	GetDlgItem(IDC_START_VIDEO_DECOMP)->EnableWindow(TRUE);
	GetDlgItem(IDC_STOP_VIDEO_DECOMP)->EnableWindow(FALSE);
	GetDlgItem(IDC_DECOMP_CONFIG)->EnableWindow(TRUE);
}


void CkdvplayertesterDlg::OnFullscreen()
{
	// TODO: Add your control notification handler code here
}


void CkdvplayertesterDlg::OnCheckActivept()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if(m_bActivePT)
	{
		m_nActivePT = m_comDecType.GetItemData(m_comDecType.GetCurSel());
		m_KdvDecoder.SetVideoActivePT(m_nActivePT,
			m_comDecType.GetItemData(m_comDecType.GetCurSel()));
        //UINT A = m_comDecType.GetItemData(m_comDecType.GetCurSel());
 		GetDlgItem(IDC_EDIT_ACTIVEPT)->EnableWindow(TRUE);
		m_comDecType.EnableWindow(TRUE);
	}
	else
	{
		m_KdvDecoder.SetVideoActivePT(0, 0);
		GetDlgItem(IDC_EDIT_ACTIVEPT)->EnableWindow(FALSE);
		m_comDecType.EnableWindow(FALSE);
	}

}


void CkdvplayertesterDlg::OnSelchangeComboDectype()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_nActivePT = m_comDecType.GetItemData(m_comDecType.GetCurSel());
	UpdateData(FALSE);
}


BOOL CkdvplayertesterDlg::DestroyWindow(void)
{
	OspQuit();
	return CDialogEx::DestroyWindow();
}


LRESULT CkdvplayertesterDlg::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	return CDialogEx::DefWindowProc(message, wParam, lParam);
}


void CkdvplayertesterDlg::OnKeyFrameCheck()
{
	// TODO: Add your control notification handler code here
	if (IsDlgButtonChecked(IDC_KEY_FRAME_CHECK) == BST_CHECKED)
	{
		m_KdvDecoder.SetOnlyKeyFrame(TRUE);
	} 
	else
	{
		m_KdvDecoder.SetOnlyKeyFrame(FALSE);
	}
}


void CkdvplayertesterDlg::OnClear()
{
	// TODO: Add your control notification handler code here
	m_KdvDecoder.ClearWindow();
}


void CkdvplayertesterDlg::OnReleasedcaptureVideoWindowSlider(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	s32 nSliderPos = m_cscVideoWindow.GetPos();
	m_cPlayerWnd.MoveWindow(20, 20, 352 + nSliderPos, 288 + 288 * nSliderPos /352);
	*pResult = 0;
}


void CkdvplayertesterDlg::OnRedraw()
{
	// TODO: Add your control notification handler code here
	//m_KdvDecoder.RedrawLastFrame();
}


void CkdvplayertesterDlg::OnStatus()
{
	// TODO: Add your control notification handler code here
	CPlayStatus cPlayStatis;
	cPlayStatis.m_pDecoder = &m_KdvDecoder;
	cPlayStatis.DoModal();
}


void CkdvplayertesterDlg::OnSnap()
{
	// TODO: Add your control notification handler code here
// 	CPicView cPicView;
// 	cPicView.SetDecoderHandle(&m_KdvDecoder);
// 	cPicView.DoModal();
}

void CkdvplayertesterDlg::OnReleasedcaptureAudioVolumeSlider(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	u16 wSliderPos = this->m_cscAudioVolume.GetPos();
	this->m_KdvDecoder.SetAudioVolume((BYTE)wSliderPos);
	*pResult = 0;
}


void CkdvplayertesterDlg::OnStartAudioDecomp()
{
	// TODO: Add your control notification handler code here
	m_KdvDecoder.StartAudioDec();

	GetDlgItem( IDC_START_AUDIO_DECOMP )->EnableWindow( FALSE );
	GetDlgItem( IDC_STOP_AUDIO_DECOMP )->EnableWindow( TRUE );
}


void CkdvplayertesterDlg::OnStopAudioDecomp()
{
	// TODO: Add your control notification handler code here
	m_KdvDecoder.StopAudioDec();

	GetDlgItem( IDC_START_AUDIO_DECOMP )->EnableWindow( TRUE );
	GetDlgItem( IDC_STOP_AUDIO_DECOMP )->EnableWindow( FALSE );
}
