
// kdvplayertesterDlg.h : ͷ�ļ�
//

#pragma once

#include "kdvtype.h"
#include "kdvdef.h"
#include "osp.h"
#include "codecwrapper_win32.h"
#include "afxwin.h"
#include "afxcmn.h"
#include "cdraw.h"
#include "winsock2.h"


// CkdvplayertesterDlg �Ի���
class CkdvplayertesterDlg : public CDialogEx
{
// ����
public:
	BOOL m_bRedrawFlag;
	CkdvplayertesterDlg(CWnd* pParent = NULL);	// ��׼���캯��
	CKdvDecoder  m_KdvDecoder;
	HANDLE      m_hAec;
	CString     m_cIp;
	s8*         m_pLocalIpAddress;
	s8*         m_pRemoteIpAddress;
// �Ի�������
	enum { IDD = IDD_KDVPLAYERTESTER_DIALOG };

public:
	virtual BOOL DestroyWindow();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);



// ʵ��
protected:
	HICON     m_hIcon;
	CStatic   m_cPlayerWnd;
	BOOL      m_bFullScreen;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	void GetLocalIp(void);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSetNetParam();
	afx_msg void OnStartNetRcv();
	afx_msg void OnStopNetRcv();
	afx_msg void OnStartVideoDecomp();
	afx_msg void OnStopVideoDecomp();
	afx_msg void OnFullscreen();
	afx_msg void OnCheckActivept();
	afx_msg void OnSelchangeComboDectype();
	afx_msg void OnKeyFrameCheck();
	afx_msg void OnClear();
	afx_msg void OnRedraw();
	afx_msg void OnStatus();
	afx_msg void OnSnap();
	afx_msg void OnReleasedcaptureVideoWindowSlider(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnReleasedcaptureAudioVolumeSlider(NMHDR *pNMHDR, LRESULT *pResult);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedButton11();
	UINT m_nVideoPort;
	UINT m_nAudioPort;
	UINT m_nRomoteVidPort;
	UINT m_nRomoteAudPort;
	BOOL m_bActivePT;
	UINT m_nActivePT;
	CComboBox m_comDecType;
	CComboBox m_comboFrame;
	CIPAddressCtrl m_cLocalIpAddr;
	CIPAddressCtrl m_cRemoteIpAddr;
	CSliderCtrl m_cscVideoWindow;
	CSliderCtrl m_cscAudioVolume;
	CStatic m_cAPStatic;
	
	afx_msg void OnStartAudioDecomp();
	afx_msg void OnStopAudioDecomp();
	//afx_msg void OnEnChangeVideoLocalPort();
};

